﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
   public class Rectangle:Shape
    {
        private int sideA;
        private int sideB;

        public Rectangle(int a, int b)
        {
          sideA = a;
          sideB = b;
        }

        public override double CalculateArea()
        {
            return sideA * sideB;
        }

        public override double CalculatePerimeter()
        {
            return sideA * 2 + sideB * 2;
        }

        public  override string Draw()
        {
            return base.Draw() + "Rectangle";
        }
    }
}
